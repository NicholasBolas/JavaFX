module edu.missouriwestern.nkempf {
    requires javafx.controls;
    requires org.yaml.snakeyaml;
    exports org.example;
}