//State class

package org.example;

import java.io.Serializable;

public class State implements Serializable {
    String name;
    String capital_city;
    int population;
    Governor governor;
    String flagUrl;


    //Empty public no-arg constructor
    public State() {
    }


    //Getters and setters
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCapital_city() {
        return capital_city;
    }
    public void setCapital_city(String capital_city) {
        this.capital_city = capital_city;
    }
    public int getPopulation() {
        return population;
    }
    public void setPopulation(int population) {
        this.population = population;
    }
    public Governor getGovernor() {
        return governor;
    }
    public void setGovernor(Governor governor) {
        this.governor = governor;
    }
    public String getFlagUrl() {
        return flagUrl;
    }
    public void setFlagUrl(String flagUrl) {
        this.flagUrl = flagUrl;
    }

    //toString method
    @Override
    public String toString() {
        return ("\nCapital City: " + getCapital_city() +
                "\nFlag Url: " + getFlagUrl() +
                "\nSate Name: " + getName() +
                "\nPopulation: " + getPopulation() +
                "\n Governor: " + getGovernor() +
                "\n");
    }

}
