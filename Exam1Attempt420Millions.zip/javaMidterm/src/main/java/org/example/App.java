/**
 * Exam 1
 * Nicholas Kempf
 *
 * On the back end, this program reads in a yaml file and stores the information as a map to be used later on.
 * On the front side, We display a dropdown menu for the user. The user then selects a state and the program wil display
 * information about the state as well as the state governor. In addition, we have a background image.
 *
 **/





package org.example;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Rectangle2D;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import org.yaml.snakeyaml.Yaml;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.*;

public class App extends Application {

    //Labels and texts, for displaying information
    static Map<String, State> map;
    Label state_name = new Label();
    Label state_capital = new Label();
    Label state_population = new Label();
    Label state_gov = new Label();


    //Texts are easier to format and move around
    Text gov_title = new Text();
    Text gov_Fname = new Text();
    Text gov_Mname = new Text();
    Text gov_Lname = new Text();
    Text gov_Gby = new Text();
    Text gov_DOB = new Text();
    Text gov_biography = new Text();
    Text gov_address = new Text();


    //Hold data for the state flag and gov picture
    Image flag_image;
    Image gov_image;
    ImageView pic = new ImageView();
    ImageView gov_pic = new ImageView();

    @Override
    public void start(Stage stage) {

        //Create scene
        var label = new Label("Main Menu");
        var scene = new Scene(new StackPane(label), 1040, 2000);


        // Sets window to fullscreen
        Screen screen = Screen.getPrimary();
        Rectangle2D bounds = screen.getVisualBounds();

        //These bounds will also be used for generality, allowing us to fit our FX to any user's screen
        stage.setX(bounds.getMinX());
        stage.setY(bounds.getMinY());
        stage.setWidth(bounds.getWidth());
        stage.setHeight(bounds.getHeight());
        //End of set fullscreen

        System.out.println(bounds.getWidth());

        //Searchbar
        TextField searchbar = new TextField();
        searchbar.setPromptText("Search here!");

        //Declare 3 panes: Parent, state, governor
        Pane pane = new FlowPane(Orientation.VERTICAL); //Home pane
        Pane pane2 = new FlowPane(Orientation.VERTICAL); //State data
        Pane pane3 = new FlowPane(Orientation.VERTICAL); //Gov data

        //Position pane 2 on the left side of the screen
        pane2.setTranslateY(-69); //nice

        //set a border, for testing and positioning purposes
        //Leave in for further pssible testing
        //pane2.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.DASHED, null, null)));

        //sets the size for the gov info.
        pane3.setMinWidth(300); //Min width
        pane3.setMaxWidth(600); //Max width
        pane3.setPrefWidth(400); //Preferred width

        //moves the gov pane to the right side of the screen, relative to the user's screen size; positioning
        //The use of bounds lets us position this correctly on any screen
        pane3.setTranslateX(bounds.getWidth()-800);
        pane3.setTranslateY(bounds.getHeight()-425);


        //set a border, for testing and moving around, keep for further testing
        //pane3.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.DASHED, null, null)));

        ChoiceBox<String> dropDown = new ChoiceBox<>(); //Choice box, allows us to pick a state
        dropDown.setPadding(new Insets(0, 10, 0, 0));  //Padding on the dropbox
        //This all shows in the home pane
        Button pick_state_button = new Button("Click Me!"); //Text that appears on the clickable button
        Label Stt_txt = new Label(""); //This heads the State text
        Label Gov_txt = new Label(""); //This heads the gov text
        //Padding on each of the panes
        pane.setPadding(new Insets(10, 10, 10, 10));
        pane2.setPadding(new Insets(10, 10, 10, 10));
        pane3.setPadding(new Insets(10, 10, 10, 10));
        //Gov_txt.setAlignment(Pos.BASELINE_RIGHT); //Not sure what this does, can be ignored for now


        //Positioning, allows us to position it correctly on any screen
        dropDown.setTranslateX((bounds.getWidth()/2)-150);
        pick_state_button.setTranslateX((bounds.getWidth()/2)-150);


        //This creates and sets a background image
        //Program looks less dull
        BackgroundImage myBI= new BackgroundImage(new Image(
                "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7b/Seal_of_the_United_States_Department_of_State.svg/2048px-Seal_of_the_United_States_Department_of_State.svg.png",
                bounds.getWidth()/3,
                bounds.getHeight()/2,
                false,
                true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);
        //Set background image to parent node
        pane.setBackground(new Background(myBI));


        //put items in the dropBox
        //Puts each of the state names in our menu
        for (String key : map.keySet()) {
            dropDown.getItems().add(key);
        }

        //Dropbox starts out as 'Missouri'
        dropDown.setValue("Missouri");

        //This is the function that pulls info for a state
        pick_state_button.setOnAction(e -> PickState(dropDown, Stt_txt));

        //This is what seperates the State and Gov data after the search button gets clicked
        pane.getChildren().addAll(dropDown, pick_state_button);
        pane2.getChildren().addAll( //State pane
                Stt_txt, state_name, state_capital, state_population, state_gov, pic);
        pane3.getChildren().addAll( //Governor pane
                Gov_txt, gov_title, gov_Fname, gov_Mname, gov_Lname, gov_Gby, gov_DOB, gov_biography, gov_address, gov_pic);

        //Set and start
        scene = new Scene(pane);
        pane.getChildren().addAll(pane2, pane3); //Adds the state and gov
        stage.setScene(scene);
        stage.show();
    } //End of Start

    //This is our method for pulling information and displaying it to the user
    private void PickState(ChoiceBox<String> dropDown, Label label) {
        String pick = dropDown.getValue(); //Takes in the value we set in our choicebox
        Set<String> names = map.keySet();
        for (String key : names) {
            if (Objects.equals(key, pick)) { //If our choice is the same as something in our map, do the following
                state_name.setText("State Name: " + map.get(key).name);
                state_capital.setText("\nState Capital: " + map.get(key).capital_city);
                state_population.setText("\nState Population: " + String.valueOf(map.get(key).population));

                //Sets gov name as nickname based on if they have a "goes_by" (if it exists, regular first name if not),
                // followed by last name
                if (map.get(key).governor.goes_by != null) {
                    state_gov.setText("State Governor: " + map.get(key).governor.goes_by + " "
                            + map.get(key).governor.last_name + "\n\n");
                } else {
                    state_gov.setText("State Governor: " + map.get(key).governor.first_name + " "
                            + map.get(key).governor.last_name + "\n\n");
                }
                //Set and format flag
                flag_image = new Image((map.get(key).flagUrl));
                pic.setFitWidth(300);
                pic.setFitHeight(200);
                pic.setImage(flag_image);

                //Position governor image
                gov_image = new Image((map.get(key).governor.photo_url));
                gov_pic.setFitWidth(400);
                gov_pic.setFitHeight(400);
                gov_pic.setImage(gov_image);
                gov_pic.toFront();
                gov_pic.setTranslateX(-400);
                gov_pic.setTranslateY(-400);

                gov_title.setText("Title: " + map.get(key).governor.title);
                gov_Fname.setText("\nFirst Name: " + map.get(key).governor.first_name);

                //Not all governors have a middle name listed, so we will leave it blank if there is none given
                if (map.get(key).governor.middle_name != null) {
                    gov_Mname.setText("\nMiddle Name: " + map.get(key).governor.middle_name);
                } else {
                    gov_Mname.setText("\nMiddle Name: ");
                }

                gov_Lname.setText("\nLast Name: " + map.get(key).governor.last_name);

                //Goes by if it exists, blank if not
                if (map.get(key).governor.goes_by != null) {
                    gov_Gby.setText("\nGoes by: " + map.get(key).governor.goes_by);
                } else {
                    gov_Gby.setText("\nGoes by: ");
                }

                gov_DOB.setText("\nDate of Birth: " + map.get(key).governor.date_of_birth);
                gov_biography.setText("\nBiography: " + map.get(key).governor.biography);
                gov_address.setText("\nAddress: " + map.get(key).governor.address_complete);

                //Maximize the number of characters that a field may take, next line when char count hits set limit
                gov_title.setWrappingWidth(200);
                gov_Fname.setWrappingWidth(200);
                gov_Mname.setWrappingWidth(200);
                gov_Lname.setWrappingWidth(200);
                gov_Gby.setWrappingWidth(200);
                gov_Gby.setWrappingWidth(200);
                gov_biography.setWrappingWidth(400);
                gov_address.setWrappingWidth(400);

                System.out.println(map.get(key));
            } //End of if statement, set information
        } //End of for
    } //End of PickState method

    public static void main(String[] args) throws FileNotFoundException {

        //Read in yaml file and create map
        Yaml yaml = new Yaml();
        InputStream inputStream = new FileInputStream
                ("statesAndGovernorsAsMap.yaml");
        map = yaml.load(inputStream);

        //Testing
        //System.out.println(map);
        launch();
    }
} //End of App

