//Governor class
package org.example;

import java.io.Serializable;

public class Governor implements Serializable {
    String state_Name;
    String title;
    String first_name;
    String middle_name;
    String last_name;
    String goes_by;
    String date_of_birth;
    String biography;
    String address_complete;
    String photo_url;

    //Empty public no-arg constructor
    public Governor (){
    }

    //Getters and setters
    public String getState_Name() {
        return state_Name;
    }
    public void setState_Name(String state_Name) {
        this.state_Name = state_Name;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getFirst_name() {
        return first_name;
    }
    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }
    public String getMiddle_name() {
        return middle_name;
    }
    public void setMiddle_name(String middle_name) {
        this.middle_name = middle_name;
    }
    public String getLast_name() {
        return last_name;
    }
    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }
    public String getGoes_by() {
        return goes_by;
    }
    public void setGoes_by(String goes_by) {
        this.goes_by = goes_by;
    }
    public String getDate_of_birth() {
        return date_of_birth;
    }
    public void setDate_of_birth(String date_of_birth) {
        this.date_of_birth = date_of_birth;
    }
    public String getBiography() {
        return biography;
    }
    public void setBiography(String biography) {
        this.biography = biography;
    }
    public String getAddress_complete() {
        return address_complete;
    }
    public void setAddress_complete(String address_complete) {
        this.address_complete = address_complete;
    }
    public String getPhoto_url() {
        return photo_url;
    }
    public void setPhoto_url(String photo_url) {
        this.photo_url = photo_url;
    }

    //toString method
    @Override
    public String toString() {
        return ("\n State Name: " + state_Name +
                "\n Title: " + title +
                "\n First Name: " + first_name +
                "\n Middle Name: " + middle_name +
                "\n Last Name: " + last_name +
                "\n Goes By: " + goes_by +
                "\n Date Of Birth: " + date_of_birth +
                "\n Biography: " + biography +
                "\n Address Complete: " + address_complete +
                "\n Photo Url: " + photo_url +
                "\n");
    }
}
